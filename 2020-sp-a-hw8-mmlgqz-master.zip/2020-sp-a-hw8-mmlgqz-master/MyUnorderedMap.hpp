using namespace std;
using std::string;
void get_identity(std::string &my_id)
{
  my_id="mmlgqz";
  return;
}

template <typename K, typename V>
int MyUnorderedMap<K,V>::hash(const K &key) const {
  int sum=0;

  for(int i=0; key[i] != '\0'; i++) 
    sum+=(int)(key[i]);

  return sum%reserved_size;
}

template <typename K, typename V>
MyUnorderedMap<K,V>::MyUnorderedMap() 
{
  m_data=nullptr;
  data_size=0;
  reserved_size=0;
}

template <typename K, typename V>
MyUnorderedMap<K,V>::~MyUnorderedMap() 
{
  delete[] m_data;
}

template <typename K, typename V>
MyUnorderedMap<K,V>::MyUnorderedMap(const MyUnorderedMap<K,V> &source) 
{
  data_size=source.data_size;
  reserved_size=source.reserved_size;
  m_data=new MyPair<K,V>[reserved_size];

  for (int i=0; i<reserved_size; i++) 
  {
    m_data[i]=source.m_data[i];
  }
}

template <typename K, typename V>
MyUnorderedMap<K,V> & MyUnorderedMap<K,V>::operator=(const MyUnorderedMap<K,V> &source)
{
  data_size=source.data_size;
  reserved_size=source.reserved_size;
 
  delete[] m_data;
 
  m_data=new MyPair<K,V>[reserved_size];

  for (int i=0; i<reserved_size; i++) 
    m_data[i]=source.m_data[i];

  return (*this);
}

template <typename K, typename V>
V & MyUnorderedMap<K,V>::at(const K &key) 
{
  MyPair<K,V> *temp=find(key);

  if (temp!=nullptr) 
    return temp->second;
  
  throw std::out_of_range("MyUnorderedMap::at");
}

template <typename K, typename V>
V & MyUnorderedMap<K,V>::operator[](const K &key) 
{
  MyPair<K,V> *temp=find(key);

  if (temp!=nullptr) 
    return temp->second;

  temp=new MyPair<K,V>(key);
  insert(*temp);

  delete temp;

  return find(key)->second;
}

template <typename K, typename V>
bool MyUnorderedMap<K,V>::empty() const 
{
  //not false (0)==true
  return (!data_size);
}

template <typename K, typename V>
int MyUnorderedMap<K,V>::size() const 
{
  return data_size;
}

template <typename K, typename V>
void MyUnorderedMap<K,V>::clear() 
{
  for (int i=0; i<reserved_size; i++) 
    m_data[i].first = "EMPTYKEY";
  
  data_size = 0;
  reserved_size = 0;

  delete[] m_data;
  m_data = nullptr;
}

template <typename K, typename V>
void MyUnorderedMap<K,V>::insert(const MyPair<K, V> &init_pair)
{
  data_size++;

  if (reserved_size == 0) 
    reserve(2);
  else if (0.6*(double)(reserved_size)<=data_size) 
    reserve(2*reserved_size);
  
  int home=hash(init_pair.first);
  int pos=home;
  for (int i = 1; 
    !(m_data[pos].first=="EMPTYKEY" || m_data[pos].first=="TOMB"); 
    i++)
    pos=(home+i)%reserved_size;

  m_data[pos]=init_pair;
}

template <typename K, typename V>
void MyUnorderedMap<K,V>::erase(const K &key) 
{
  int home=hash(key);
  int pos=home;

  for (int i = 1; 
    !(m_data[pos].first=="EMPTYKEY" || m_data[pos].first ==key);
    i++)
    pos=(home+i)%reserved_size;

  if (m_data[pos].first!="EMPTYKEY") 
  {
    m_data[pos].first = "TOMB";
    data_size--;

    if (.1*(double)(reserved_size)>=data_size) 
      reserve(.3*(double)(reserved_size));
  }
}

template <typename K, typename V>
MyPair<K, V> * MyUnorderedMap<K,V>::find(const K &key) const 
{
  if (data_size==0 || reserved_size==0)
    return nullptr;
  
  int home=hash(key);
  int pos=home;

  for (int i = 1; 
   !(m_data[pos].first=="EMPTYKEY" || m_data[pos].first==key);
    i++)
    pos=(home+i)%reserved_size;
  
  if (m_data[pos].first==key) 
    return &m_data[pos];

  return nullptr;
}

template <typename K, typename V>
void MyUnorderedMap<K,V>::print() const 
{
  bool first = true;
  cout << "[";

  for (int i=0; i<reserved_size; i++) 
  {
    if (!(m_data[i].first=="EMPTYKEY" || m_data[i].first=="TOMB")) 
    {
      if (!first) 
        cout << ", ";
      else 
        first = false;
      
      cout << "(" << m_data[i].first << ": " << m_data[i].second << ")";
    }

  }
  cout << "]";
}

template <typename K, typename V>
int MyUnorderedMap<K,V>::count(const K &key) const 
{
  int count=0;
  int home=hash(key);
  int pos=home;

  for (int i=0; m_data[pos].first!="EMPTYKEY"; i++) 
  {
    pos=(home+i)%reserved_size; 
    if(key==m_data[pos].first)  
      count++;
  }
  return count;
}

template <typename K, typename V>
void MyUnorderedMap<K,V>::reserve(int new_cap) 
{
  MyPair<K,V> *temp=new MyPair<K,V>[reserved_size];
 
  for (int i=0; i<reserved_size; i++) 
    temp[i]=m_data[i];

  delete[] m_data;

  m_data=new MyPair<K,V>[new_cap];

  for (int i=0; i<new_cap; i++) 
    m_data[i].first = "EMPTYKEY";
  
  int old_cap=reserved_size;
  reserved_size=new_cap;

  for (int i=0; i<old_cap; i++)
  {
    if (!(temp[i].first=="EMPTYKEY" || temp[i].first=="TOMB")) 
    {
      int home=hash(temp[i].first);
      int pos=home;
      for (int j=1;
       !(m_data[pos].first=="EMPTYKEY" || m_data[pos].first=="TOMB");
       j++) 
        pos=(home+j)%reserved_size;
      m_data[pos]=temp[i];
    }
  }
  delete[] temp;
}

void get_virus_frequency(MyUnorderedMap<std::string, int> &in_tree)
{
  string word;
  string word_lower;
  bool keep_looking=true;
  int begin;
  int end;
  string sub_str;

  //get word by word
  while(cin>>word)
  {
    do
    {//make everything lowercase
      for(int i=0; i<word.size(); i++)
      {
        if(isupper(word[i]))
          word_lower+=tolower(word[i]);
        else
          word_lower+=word[i];
      }
      //word to short to possibly be virus so stop
      if(word.size()<5)
        keep_looking=false;
      else if(word_lower.find("virus") != std::string::npos)
      {
        //find beginning pos
        for(int j=word_lower.find("virus"); j>=0; j--)
        {
          if(isalpha(word[j]) || word[j]=='_' || isdigit(word[j]))
          {
            begin=j;
          }
          else
            j=-1;
        }
        //find end
        for(int i=word_lower.find("virus"); i<word.size(); i++)
        {
          if(isalpha(word[i])|| word[i]=='_' || isdigit(word[i]))
            end=i;
          else
            i=word.size();
        }

        sub_str=word.substr(begin,end-begin+1);
        end++;


        if(end<word.size())
        {
          word=word.substr(end);
          keep_looking=true;
        }
        else
          keep_looking=false;

        //store in hash
        if(in_tree.find(sub_str)==nullptr)
        {
           MyPair<string,int> temp(sub_str,1);
           in_tree.insert(temp);
        }
        else
          in_tree.at(sub_str)=in_tree.at(sub_str)+1;
      
      }
      else
        keep_looking=false;

      word_lower="";//reset string

    }while(keep_looking);
  }
 
   return;
}
