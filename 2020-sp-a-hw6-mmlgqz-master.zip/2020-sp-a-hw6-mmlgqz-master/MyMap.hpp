using std::string;

void get_identity(std::string &my_id)
{
  my_id="mmlgqz";
  return;
}


//--------------PUBLIC-------------------------------------
template <typename K, typename V>
MyMap<K,V>::MyMap()
{
  root=nullptr;
}

//--------------PRIVATE------------------------------------

//"Returns a refence to the mapped value of the element with key equivalent 
// to key if no such element exists, an exception of type std::out_of_range 
//is thrown
template <typename K, typename V>
V & MyMap<K,V>::at_helper(TreeNode<MyPair<K,V>> *&rt, const K &key)
{
  MyPair<K,V> *temp=find_helper(rt,key);

  if (temp!=nullptr)
    return temp->second;
  else
  {
    throw std::out_of_range("MyMap::at\n");
   // throw std::out_of_range("out of range\n\n");
  }
}

template <typename K, typename V>
int MyMap<K,V>::size_helper(TreeNode<MyPair<K,V>> *rt) const 
{
   int count;

   if (rt==nullptr)
     return 0;
   else //recursively count number of nodes on each side
   {   
      count=1;
      count=count+size_helper(rt->right);
      count=count+size_helper(rt->left); 
      return count;
   }

  // return count; want to stop recursion
}

template <typename K, typename V>
void MyMap<K,V>::clear_helper(TreeNode<MyPair<K,V>> *&rt) 
{
  if (rt==nullptr)
    return;//end recursion
  
  clear_helper(rt->left);
  clear_helper(rt->right);

  delete rt;
  rt=nullptr;
}

template <typename K, typename V>
void MyMap<K,V>::insert(const MyPair<K,V> &init_pair)
{
  insert_helper(root,init_pair);
//  cout<<"Hello"<<endl;
}

template <typename K, typename V>
void MyMap<K,V>::insert_helper(TreeNode<MyPair<K,V>> *&rt, const MyPair<K,V> &init_pair)
{
  if (rt==nullptr)//if first thing
    rt=new TreeNode<MyPair<K,V>>(init_pair,nullptr,nullptr);
  else if (init_pair.first < rt->data.first)
    insert_helper(rt->left,init_pair);
  else 
    insert_helper(rt->right,init_pair);
}

template <typename K, typename V>
TreeNode<MyPair<K,V>> * MyMap<K,V>::get_min(TreeNode<MyPair<K,V>> * rt)
{
  //min will be on left always
  if (rt->left==nullptr)
    return rt;
  else
    return get_min(rt->left);
}

template <typename K, typename V>
void MyMap<K,V>::erase_helper(TreeNode<MyPair<K,V>> *&rt, const K &key)
{
  if(rt==nullptr)//unnecessary?
    return;
  else if (key<rt->data.first)
    erase_helper(rt->left,key);
  else if (key>rt->data.first)
    erase_helper(rt->right,key);
  else//delete, key was found 
  {
    TreeNode<MyPair<K,V>> *temp=rt;
    
    if (rt->left==nullptr)//if tehre is only a right child or no child 
    {
       rt=rt->right;
       delete temp;
    }
    else if (rt->right==nullptr)
    {
       rt=rt->left;
       delete temp;
    }
    else//two children
    {
       TreeNode<MyPair<K,V>> *temp2=get_min(rt->right);
       rt->data=temp2->data;
       erase_helper(rt->right,temp2->data.first);
    }
  }
}

template <typename K, typename V>
MyPair<K,V> * MyMap<K,V>::find_helper(TreeNode<MyPair<K,V>> *rt, const K &key) const
{
  if (rt==nullptr)//empty
    return nullptr;

  if (key<rt->data.first)
    return find_helper(rt->left,key);
  else if (key>rt->data.first)
    return find_helper(rt->right,key);
  else 
    return &rt->data; 
}

template <typename K, typename V>
void MyMap<K,V>::print_helper(TreeNode<MyPair<K,V>> *rt, std::string indent) const
{
  if (rt==nullptr)
  {
     cout<<indent<<"   [empty]"<<endl;
     return;   
  }
  
   print_helper(rt->right,indent+="  ");
   cout<<indent<<" ["<<rt->data.first<<"]="<<rt->data.second<<endl;
   print_helper(rt->left,indent+="");
}

template <typename K, typename V>
int MyMap<K,V>::count_helper(TreeNode<MyPair<K,V>> *rt, const K &key) const
{
  return (find_helper(rt,key)!=nullptr);
}

template <typename K, typename V>
TreeNode<MyPair<K,V>> *MyMap<K,V>::clone(const TreeNode<MyPair<K,V>> *rt)
{
  if (rt==nullptr)
    return nullptr;
  
   TreeNode<MyPair<K,V>> *temp=new TreeNode<MyPair<K,V>>(rt->data,rt->left,rt->right);
   temp->right=clone(rt->right);
   temp->left=clone(rt->left);
   return temp;
}
//--------------PUBLIC-------------------------------------

template <typename K, typename V>
MyMap<K,V>::~MyMap()
{
  clear_helper(root);
  root=nullptr;
}

template <typename K, typename V>
MyMap<K,V>::MyMap(const MyMap<K,V> &source)
{
  root=clone(source.root);
}

template <typename K, typename V>
MyMap<K,V> & MyMap<K,V>::operator=(const MyMap<K,V> & source)
{
  clear_helper(root);
  root=clone(source.root);
  return (*this);
}

template <typename K, typename V>
V & MyMap<K,V>::at(const K &key)
{
  at_helper(root,key);
  //compiler mad no return
}

//----------------------------------giving weird text error
template <typename K, typename V>
V & MyMap<K,V>::operator[](const K &key)
{
  MyPair<K,V> *temp=find_helper(root,key);  
 
  if (temp!=nullptr)
    return temp->second;//
  else
  {
    temp=new MyPair<K,V>(key);
    insert_helper(root,*temp);
    delete temp;
    return find_helper(root,key)->second;
  }
}

template <typename K, typename V>
bool MyMap<K,V>::empty() const
{
  if(root==nullptr)
    return true;
  return false;
}

template <typename K, typename V>
int MyMap<K,V>::size() const
{
  return size_helper(root);
}

template <typename K, typename V>
void MyMap<K,V>::clear()
{
  clear_helper(root);
  root=nullptr;
}

//-----------------------------------------giving weird text error

template <typename K, typename V>
void MyMap<K,V>::erase(const K & key)
{
  erase_helper(root,key);
}

template <typename K, typename V>
MyPair<K,V> * MyMap<K,V>::find(const K & key) const
{
  find_helper(root,key);  
}

template <typename K, typename V>
void MyMap<K,V>::print() const
{
  print_helper(root,"");
}

template <typename K, typename V>
int MyMap<K,V>::count(const K &key) const
{
  return count_helper(root,key);
}

//Define get_letter_frequency function
void get_letter_frequency(MyMap<char, int> &in_tree)
{
  char c;
  while (cin.get(c))//character var
  {
     if ( !( (static_cast<int>(c))>=0 && (static_cast<int>(c))<=31 )
       && c!='\n' )
     {
        if (in_tree.find(c)==nullptr)
        {
          MyPair<char, int> temp(c,1);
          in_tree.insert(temp);
        }
        else 
        {
          in_tree.at(c)=in_tree.at(c)+1;
        }  
      
     }
  
  }
}

