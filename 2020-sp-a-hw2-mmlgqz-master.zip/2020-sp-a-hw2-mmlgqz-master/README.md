Programming assignment 2 (PA02)
==============================

# Inheritance, Polymorphism, and Exception Handling

<img src="bags.jpg" width="200">

## with bags


The files listed here are the starting point for your assignment.
Only add source files (not compiled files) to the Git repository.

Remember, the assignment due date is posted on the course website.

Thoroughly read the Canvas page **How to: Homework Submissions** for good tips, tricks, hints, and instructions on programming assignments, including how to submit via Git.

See the headers of each of the files in this repository for instructions.

The first step is to read all the code and see how it works together (start with **pa02.cpp**). 

Remember, only cpp files should be compiled, not h or hpp, and never include a cpp file via #include.
