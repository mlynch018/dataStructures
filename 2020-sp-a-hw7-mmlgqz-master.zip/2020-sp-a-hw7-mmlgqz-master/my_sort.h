// Mimic the std:: version

#ifndef MY_SORT_H
#define MY_SORT_H

#include "MyHeap.h"

template <typename T>
void my_sort(T array, int size)
{
  int s=size;
  int pos;

  for (int i=size/2 -1; i>=0; i--)
  {
    pos=i;
    
    while (pos<size/2)
    {
      int j=2*pos +1;
      
      if (((j+1)<size) && (array[j]<array[j+1]))
        j++;

      if (!(array[pos]<array[j]))
        break;

      std::swap(array[pos],array[j]);
      pos=j;	      
    }  
  }
//-------------------------------------------------

  for (size--; size>0; size--)
  {
    std::swap(array[0],array[size]);
    pos=0;
    
    while (pos<size/2)
    {
       int j=2*pos +1;
   
       if (((j+1)<size) && (array[j]<array[j+1]))
	 j++;

       if(!(array[pos]<array[j]))
         break;

       std::swap(array[pos],array[j]);
       pos=j;
    }
  }

//  for (int i=0; i<s/2; i++)
 //   std::swap(array[i],array[s-i-1]);

  return;
}

#endif
