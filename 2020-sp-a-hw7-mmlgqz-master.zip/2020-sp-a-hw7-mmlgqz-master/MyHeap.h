// You don't need to have a MyHeap.hpp, but you could if you want
// Declare, and/or implement your heap class here. 
// If you are having a hard time figuring out how to start, look at the past assignments.

#ifndef MYHEAP_H
#define MYHEAP_H

//standard includes
#include <iostream>
#include <string>
#include <stdexcept>

//file includes
#include "my_sort.h"
#include "my_is_sorted.h"

//using std
using std::string;
using std::cout;
using std::endl;

void get_identity(std::string &my_id);

//CLASS-------------------------------------------------------------------
template <typename T>
class MyHeap
{
  private:
    T *m_arr=nullptr;
    int max_size=0;
    int num_ele=0;

    //helper functions   
    void reserve(int new_cap);		    

    void shrink_to_fit();

    void siftdown(int i);
    	
  public:
    MyHeap();    

    MyHeap(T *h, int num);	

    MyHeap(const MyHeap<T> &source);
 
    ~MyHeap();

    MyHeap<T> & operator=(const MyHeap<T> & source);	

    T top();

    void pop();

    void push(const T &x);

    bool empty();

    int size();
};
//END of class------------------------------------------------------------
void get_identity(std::string &my_id)
{
  my_id="mmlgqz";
  return;
}
//methods----------------------------------------------------------------

template <typename T>
MyHeap<T>::MyHeap()
{
  m_arr=nullptr;
  max_size=0;
  num_ele=0;
}

//WIP______________________________________*
template <typename T>
MyHeap<T>::MyHeap(T *h, int num)
{

//  m_arr=h;

  max_size=2*num;
  num_ele=num;

  m_arr=new T[max_size];
  for (int i=0; i<num; i++)
    m_arr[i]=h[i];


  for (int i=(num_ele-2)/2; i>=0; i--)
    siftdown(i);
}

template <typename T>
MyHeap<T>::MyHeap(const MyHeap<T> &source)
{
   max_size=source.max_size;
   num_ele=source.num_ele;
   m_arr=new T[max_size];   

   for (int i=0; i<num_ele; i++)
     m_arr[i]=source.m_arr[i];

}

template <typename T>
MyHeap<T>::~MyHeap()
{
  delete[] m_arr;
}

template <typename T>
MyHeap<T> & MyHeap<T>::operator=(const MyHeap<T> & source)
{
  max_size=source.max_size;
  num_ele=source.num_ele;
  m_arr=new T[max_size];

  for (int i=0; i<num_ele; i++)
    m_arr[i]=source.m_arr[i];

  return *this;
}

template <typename T>
T MyHeap<T>::top()
{
  return m_arr[0];
}

template <typename T>
void MyHeap<T>::pop()
{
  num_ele--;

  std::swap(m_arr[0],m_arr[num_ele]);

  if (num_ele!=0)
    siftdown(0);
  
  if (num_ele < (max_size/4) )
    shrink_to_fit();

  return;
}

template <typename T>
void MyHeap<T>::push(const T &x)
{
   if(num_ele==0)
     reserve(1);

   num_ele++;

   if (num_ele==max_size)
     reserve((2*num_ele));

   m_arr[num_ele-1]=x;

   for (int i=((num_ele-2)/2); i>=0; i--)
     siftdown(i);
}

template <typename T>
bool MyHeap<T>::empty()
{
   return (!num_ele);
}

template <typename T>
int MyHeap<T>::size()
{
   return num_ele;
}

//helper functions--------------------------------------------------------
//reserve, shrink to fit, siftdown
template <typename T>
void MyHeap<T>::reserve(int new_cap)
{
  if(new_cap>max_size)
  {
    max_size=new_cap;

    T *temp=new T[max_size];
    for (int i=0; i<num_ele; i++)
	temp[i]=m_arr[i];

    delete[] m_arr;

    m_arr=new T[new_cap];

    for (int i=0; i<num_ele; i++)
	m_arr[i]=temp[i];

    delete[] temp;
  }
 
  return;
}

template <typename T>
void MyHeap<T>::shrink_to_fit()
{
   max_size=(2*num_ele);
  
   T *temp=new T[max_size];
   for (int i=0; i<num_ele; i++)
      temp[i]=m_arr[i];

   delete[] m_arr;

   m_arr=new T[max_size];

   for (int i=0; i<num_ele; i++)
      m_arr[i]=temp[i];

   delete[] temp;

  return;
}

template <typename T>
void MyHeap<T>::siftdown(int pos)
{
  while(!( (pos<num_ele) && (pos>=(num_ele/2)) ) )
  {
     int largest= (2*pos)+1;
     int rightchild= (2*pos)+2;
     
     if ((rightchild<num_ele) && (m_arr[rightchild]>m_arr[largest]))
       largest=rightchild;
     
     if (m_arr[pos]>m_arr[largest])
       return;
 
     std::swap(m_arr[pos],m_arr[largest]);
     pos=largest;
     
  }
  return;
}

#endif
