
#include "matrix_search.h"

#include <iostream>

int main()
{

  char** matrix;

  int num_matrices;
  int num_rows, num_cols;

  int sol[4];
  string word;

  cin >> num_matrices;

  for (int i = 0; i < num_matrices; i++)
  {
    cin >> num_rows;
    cin >> num_cols;


    matrix = build_matrix(num_rows, num_cols);
    fill_matrix(num_rows, num_cols, matrix);

    cin.ignore(80, '\n');
    getline(cin, word);

    if (word.size() > num_rows && word.size() > num_cols)
    {
      cout << "Searching for \"" << word << "\" in matrix " << i << " yields:";
      cout <<endl<< "The pattern was not found." << endl<<endl;
    }
    else
    {
      //print_matrix(num_rows, num_cols, matrix);
      matrix_search(sol, word, num_rows, num_cols, matrix);

      cout << endl;


      cout << "Searching for \"" << word << "\" in matrix " << i << " yields:" << endl;


      if (sol[0] == -1 && sol[1] == -1 && sol[2] == -1 && sol[3] == -1)
      {
        cout << "The pattern was not found." << endl<<endl;
      }
      else
      {
        cout << "Start pos:(" << sol[0] << "," << sol[1] << ")";
        cout << " to End pos:(" << sol[2] << "," << sol[3] << ")";
        cout<<endl<<endl;
      }

      delete_matrix(num_rows, matrix);

    }
  }
 
  return 0;
}
