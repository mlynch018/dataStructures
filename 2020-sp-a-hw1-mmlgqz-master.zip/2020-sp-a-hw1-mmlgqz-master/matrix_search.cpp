
#include "matrix_search.h"


// We're giving you this one the first time, and you should copy it into all future assignments.
// Change the information to your own email handle (S&T username)
void get_identity(string &my_id)
{
    my_id = "mmlgqz";
}


char ** build_matrix(int rows, int cols)
{
  char** matrix = new char* [rows];
  for (int i = 0; i < rows; i++)
  {
    matrix[i] = new char[cols];
  }
  return matrix;
}


void fill_matrix(int rows, int cols, char **matrix)
{
  for (int i = 0; i < rows; i++)
  {
    for (int j = 0; j < cols; j++)
    {
      cin >> matrix[i][j];
    }
  }
  return;
}


void print_matrix(int rows, int cols, char **matrix)
{
  for (int i = 0; i < rows; i++)
  {
    for (int j = 0; j < cols; j++)
    {
      cout << matrix[i][j];
      if (j < (cols - 1))
      {
        cout << " ";
      }
    }
    if (i < (rows - 1))
    {
      cout << endl;
    }
  }
  return;
}


void delete_matrix(int rows, char **matrix)
{
  for (int i = 0; i < rows; i++)
  {
    delete[]matrix[i];
  }
  delete[]matrix;
  matrix = nullptr; 
  return;
}


void matrix_search(int sol[], string word, int rows, int cols, char **matrix)
{
  int len = word.size();
  bool found = false;
  int c, d;

  for (int i = 0; i < 4; i++)
  {
    sol[i] = -1;
  }

  //horizontially left to right
  for (int i = 0; i < rows; i++)
  {
    for (int j = 0; j <= (cols - len); j++)
    {
      c = j;
      for (int k = 0; k < len; k++)
      {
        if (matrix[i][c] != word[k])
        {
  	  break;
        }
        else
        {
          if (k == (len - 1))
          {
            found = true;
            sol[0] = i;
            sol[1] = j;
            sol[2] = i;
            sol[3] = c;
          }
        }
        c++;

      }

    }
  }

  if (!found)
  {
    //horizontially right to left
    for (int i = 0; i < rows; i++)
    {
      for (int j = (cols - 1); (j - len) >= -1; j--)
      {

        c = j;
        for (int k = 0; k < len; k++)
        {
          if (matrix[i][c] != word[k])
          {
            break;
          }
          else
          {
            if (k == (len - 1))
            {
              found = true;
              sol[0] = i;
              sol[1] = j;
              sol[2] = i;
              sol[3] = c;
            }
          }
        c--;
        }

      }
    }
  }

  if (!found)
  {
    //vertically up to down
    for (int i = 0; i < cols; i++)
    {
      for (int j = 0; (len - j) > 1; j++)
      {
	c = j;
        for (int k = 0; k < len; k++)
        {
          if (matrix[c][i] != word[k])
          {
            break;
          }
          else
          {
            if (k == (len - 1))
            {
              found = true;
              sol[0] = j;
              sol[1] = i;
              sol[2] = c;
              sol[3] = i;
            }
          }
          c++;
        }
      }
    }
  }

  if (!found)
  {
    //vertically down to up
    for (int i = 0; i < cols; i++)
    {
      for (int j = (rows - 1); (j - len) >= -1; j--)
      {
        c = j;
        for (int k = 0; k < len; k++)
        {
          if (matrix[c][i] != word[k])
          {
            break;
          }
          else
          {
            if (k == (len - 1))
            {
              found = true;
              sol[0] = j;
              sol[1] = i;
              sol[2] = c;
              sol[3] = i;
            }
          }
          c--;
        }
      }
    }
  }

  if (!found)
  {
    //diagonally bottom right to top left
    for (int i = (rows - 1); (i - len) > -1; i--)
    {
      d = i;
      for (int j = (cols - 1); (j - len) >= -1; j--)
      {

        c = j;
        for (int k = 0; k < len; k++)
        {
          if (matrix[d][c] != word[k])
          {
            break;
          }
          else
          {
            if (k == (len - 1))
            {
              found = true;
              sol[0] = i;
              sol[1] = j;
              sol[2] = d;
              sol[3] = c;
            }
          }
          c--;
          d--;
        }

      }
    }

    if (!found)//first row was breaking 
    {
      int row=len-1;
      int c=0;
      for (int i=(len); i>0; i--)
      {
        c=i;
        for (int k=0; k<len; k++)
        {
          if (matrix[row][c] != word[k])
          {
            break;
          }
          else 
          {
            if (k==(len-1))
            {
              found=true;
              sol[0]=i-1;
              sol[1]=i;
              sol[2]=0;
              sol[3]=c;
            }
          }
          row--;
          c--;
        }
        row=len-1;
      }
    }
  }

  if (!found)
  {
    //diagonally top left to bottom right
    for (int i = 0; (i+len) <= rows; i++)
    {
      d = i;
      for (int j = 1; j <= (cols-len); j++)
      {

        c = j;
        for (int k = 0; k < len; k++)
        {
          if (matrix[d][c] != word[k])
          {
            break;
          }
          else
          {
            if (k == (len - 1))
            {
              found = true;
              sol[0] = i;
              sol[1] = j;
              sol[2] = d;
              sol[3] = c;
            }
          }
          c++;
          d++;
        }
      }
    }

    if (!found)//first col was breaking
    {
      int col=0;
      int r=0;
      for (int i=0; i<rows; i++)
      {
         r=i;
         for (int k=0; k<len; k++)
         {
           if (matrix[r][col] != word[k])
           {
             break;
           }
           else 
           {
             if (k==(len-1))
             {
               found=true;
               sol[0]=i;
               sol[1]=0;
               sol[2]=r;
               sol[3]=col;
             }
           }
           col++;
           r++;
         }
         col=0;
      }   
   
    }
  }
  
  if (!found)
  {
    //bottom left to top right 
    for (int i = (rows - 1); (i - len) >= -1; i--)
    {
      d = i;
      for (int j = 0; j < (cols - len); j++)
      {

        c = j;
        for (int k = 0; k < len; k++)
        {
          if (matrix[d][c] != word[k])
          {
            break;
          }
          else
          {
            if (k == (len - 1))
            {
              found = true;
              sol[0] = i;
              sol[1] = j;
              sol[2] = d;
              sol[3] = c;
            }
          }
          c++;
          d--;
        }
      }
    }

  }

  
  if (!found)
  {
    //top right to bottom left
    for (int i = 0; i < rows; i++)
    {
      d = i;
      for (int j = (cols - 1); (j - len) >= -1; j--)
      {

        c = j;
        for (int k = 0; k < len; k++)
        {
          if (matrix[d][c] != word[k])
          {
            break;
          }
          else
          {
            if (k == (len - 1))
            {
              found = true;
              sol[0] = i;
              sol[1] = j;
              sol[2] = d;
              sol[3] = c;
            }
          }
          c--;
          d++;
        }

      }
    }
  }

}

