
void get_identity(string &my_id)
{
  my_id="mmlgqz";
}

template <typename T>
MyList<T>::MyList()
{
    m_sentinel = new Node<T>(nullptr,nullptr);
    m_size = 0;
}

template <typename T>
MyList<T>::~MyList()
{
    clear();
    delete m_sentinel;
}

template <typename T>
MyList<T> & MyList<T>::operator=(const MyList<T> &source)
{
  clear();
  Node<T> *lhs=source.m_sentinel;

  for (int i=0; i<source.m_size; i++)
  {
    lhs=lhs->m_next;
    push_back(lhs->m_element);
  }

  return (*this);
}

template <typename T>
MyList<T>::MyList(const MyList<T> &source) 
{
  m_sentinel=new Node<T>(nullptr,nullptr);
  m_size=0;
  Node<T> *lhs=source.m_sentinel;

  for (int i=0; i<source.m_size; i++)
  {
    lhs=lhs->m_next;
    push_back(lhs->m_element);
  }
}

template <typename T>
void MyList<T>::assign(int count, const T &value) 
{//idk--not sure what supposed to do if stuff already in list
//look up normal functionality
  clear();
  delete m_sentinel;

  m_sentinel=new Node<T>(nullptr,nullptr);
  m_size=0;

  for (int i=0; i<count; i++)
    push_back(value);

  return; 
}

template <typename T>
void MyList<T>::clear()
{
  Node <T> *temp;

  for (int i=0; i<m_size; i++)
  {
    temp=m_sentinel;
    m_sentinel=m_sentinel->m_next;
    delete temp;
  }

  m_size=0;

  return;
}

template <typename T>
void MyList<T>::push_front(const T &x)
{
  if(m_sentinel->m_next != nullptr)
  {
    Node<T>* temp=new Node<T>(x,m_sentinel,m_sentinel->m_next);
    m_sentinel->m_next->m_prev=temp;
    m_sentinel->m_next=temp;
  }
  else
  {
    Node<T>* temp=new Node<T>(x,m_sentinel,m_sentinel);
    m_sentinel->m_next=temp;
    m_sentinel->m_prev=temp;
  }
  m_size++;
  return;
}

template <typename T>
void MyList<T>::push_back(const T &x)
{
  if(m_sentinel->m_prev != nullptr)
  {
    Node<T>* temp=new Node<T>(x,m_sentinel->m_prev,m_sentinel);
    m_sentinel->m_prev->m_next=temp;
    m_sentinel->m_prev=temp;
  }
  else
  {
    Node<T>* temp=new Node<T>(x,m_sentinel,m_sentinel);
    m_sentinel->m_next=temp;
    m_sentinel->m_prev=temp;
  }
  m_size++;
  return;
}

template <typename T>
void MyList<T>::pop_front()
{
  if(m_sentinel->m_next != nullptr)
  {
    Node<T>* temp=m_sentinel->m_next;
    m_sentinel->m_next->m_next->m_prev=m_sentinel;
    m_sentinel->m_next=m_sentinel->m_next->m_next;

    delete temp;
    m_size--;
  }
  return;
}

template <typename T>
void MyList<T>::pop_back()
{
  if(m_sentinel->m_prev != nullptr)
  {
    Node<T>* temp=m_sentinel->m_prev;
    m_sentinel->m_prev->m_prev->m_next=m_sentinel;
    m_sentinel->m_prev=m_sentinel->m_prev->m_prev;
   
    delete temp;
    m_size--;
  }
  return;
}


template <typename T>
void MyList<T>::insert(int i, const T &x)
{
  Node<T>* temp=m_sentinel->m_next;

  for(int c=0; c<i; c++)
    temp=temp->m_next;

  Node<T> *temp2=new Node <T>(x,temp->m_prev,temp);
  temp2->m_next->m_prev=temp2;
  temp2->m_prev->m_next=temp2;

  temp=nullptr;//fixes valgrind errors when inserting at l.end()
  delete temp;
  m_size++;

  return;
}

template <typename T>
void MyList<T>::remove(T value)
{
  Node<T> *temp=m_sentinel->m_next;
  int count=m_size;//need b/c changing size in loop

  for (int i=0; i<count; i++)
  {
    if(value==temp->m_element)
    {
      Node<T> *temp2=temp;

      temp->m_next->m_prev=temp->m_prev;
      temp->m_prev->m_next=temp->m_next;
      temp=temp->m_next;

      delete temp2;
      m_size--;
    }
    else 
      temp=temp->m_next;
  }
  return;
}

template <typename T>
void MyList<T>::erase(int i)
{
  //or else deletes first for no reason
  if (!(i>m_size || i<0)) 
  {
  Node<T> *temp=m_sentinel->m_next;

  for (int c=0; c<(i-1); c++)
    temp=temp->m_next;

  temp->m_next->m_prev=temp->m_prev;
  temp->m_prev->m_next=temp->m_next;

  delete temp;
  m_size--;
  }
  return;
}

template <typename T>
void MyList<T>::reverse()
{
  if (empty()==false)//only do if not empty
  {
    MyList<T> reversed;
    int c=m_size;
    for (int i=0; i<c; i++)
    {
      reversed.push_back(m_sentinel->m_prev->m_element);
      pop_back();
    }
    (*this)=reversed;
  }


  return;
}

template <typename T>
T & MyList<T>::front()
{
    return m_sentinel->m_next->m_element;
}

template <typename T>
T & MyList<T>::back()
{
    return m_sentinel->m_prev->m_element;
}

template <typename T>
bool MyList<T>::empty()
{
    if(m_sentinel->m_next != nullptr)
        return false;

    return true;
}

template <typename T>
int MyList<T>::size()
{
    return m_size;
}
