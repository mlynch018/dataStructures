/* Define all your MyVector-related functions here.
 * Also, define the swap function here.
 * You do not need to include the h file.
 * It included this file at the bottom.
 */

//WIP = overload,shrink part(called in assign)

void get_identity(string &my_id)
{
   my_id="mmlgqz";
}

template <typename T>
void MySwap(T &a, T&b)
{
   T temp=a;
   a=b;
   b=temp;
   return;
}

template <typename T>
MyVector<T>::MyVector()//?
{
  reserved_size=0;
  data_size=0;
  m_data=new T[reserved_size];//nullptr?yes
}

// We're giving you this one for free
// and as a guide for the syntax.
template <typename T>
MyVector<T>::~MyVector()
{
    delete[] m_data;
}

template <typename T> 
MyVector<T> & MyVector<T>::operator=(const MyVector<T> &source)//?
{
  if (this != &source)//why copy same thing
  {  
    //delete m_data? 
    data_size=source.data_size;
    reserved_size=source.reserved_size;

   // *m_data=*(source.m_data);
    m_data=new T[reserved_size];

    for (int i=0; i<data_size; i++)
      m_data[i]=source.m_data[i];
//    return *this;  //need deferencing operator
  }
  return *this; 
}

template <typename T>
MyVector<T>::MyVector(const MyVector<T> &source)//?
{
  data_size=source.data_size;
  reserved_size=source.reserved_size;
 // *m_data=*(source.m_data);

  m_data=new T[reserved_size];

  for (int i=0; i<data_size; i++)
    m_data[i]=source.m_data[i];

  //only diff not return this?
  return;
}

template <typename T>
T & MyVector<T>::operator[](int i)
{
  return m_data[i];
}

// Another example: remember when writing an implementation in hpp,
// return type first, then scope just before the function name.
template <typename T>
T & MyVector<T>::at(int index)
{
  if (index<0 || (size()<=index))
    throw std::out_of_range("invalid value");

  return m_data[index]; 
}

template <typename T>
T & MyVector<T>::front()
{
  return m_data[0];
}

template <typename T>
T & MyVector<T>::back()
{
  int end=data_size-1;
  return m_data[end];
}

template <typename T>
int MyVector<T>::capacity()
{
  return reserved_size;
}

template <typename T>
void MyVector<T>::reserve(int new_cap)
{
  if (new_cap>reserved_size)
  {
    reserved_size=new_cap;

    //make a temporary pointer and save the old data in it  
    T *temp=new T[reserved_size];
    for (int i=0; i<data_size; i++)
      temp[i]=m_data[i];
    
    //delete the old pointer
    delete[] m_data;
   // clear();

    //make a new bigger pointer and fill with old data
    m_data=new T[reserved_size]; 
    for (int i=0; i<data_size; i++)
      m_data[i]=temp[i];

    //delete temp
    delete[] temp;
  }
  return;
}

template <typename T>
void MyVector<T>::shrink_to_fit()//?
{
  //makes reserved size smaller
  reserved_size=data_size*2;
  
  //make a temp ptr and save old data
  T *temp=new T[data_size];
  for (int i=0; i<data_size;i++)
    temp[i]=m_data[i];

  //delete old
 delete[] m_data;
  // clear();

  //remake og pointer
  m_data=new T[reserved_size];

  //fill with old data
  for (int i=0; i<data_size; i++)
    m_data[i]=temp[i];

  delete[] temp;      

  return;
}

template <typename T>
void MyVector<T>::assign(int count,const T&value)
{
   data_size=count;

  int more_space=((count*2)-reserved_size);
  int afourth=reserved_size/4;

  //if we dont have enough space
  if (reserved_size<count)
    reserve(more_space);
  else if (afourth>count)//array is less than 1/4 full
    shrink_to_fit();//??

  for (int i=0; i<count; i++)
    m_data[i]=value;//not data_size+i or something bc replaces current

  return;
}

template <typename T>
void MyVector<T>::clear()
{
  data_size=0;
  reserved_size=0;

  delete[] m_data;
  m_data=nullptr;

  return;
}

template <typename T>
void MyVector<T>::push_back(const T &x)
{
  //first thing, special case needed to grow to one
  if (!data_size)//!0=true
    reserve(1);
//else if ?
  //at end
  if (reserved_size==(data_size+1))//=<
    reserve((data_size+1));

  m_data[data_size]=x;
  data_size++;

  return;
}

template <typename T>
void MyVector<T>::pop_back()//?
{
  data_size--;
  //dont need?
 // m_data[data_size]=null;

//  int afourth=reserved_size/4; 

 // if (afourth>reserved_size)//array is less than 1/4 full
   // shrink_to_fit();//?? where check

  return;
}

template <typename T>
void MyVector<T>::insert(int i, const T&x)
{
  data_size++;

  int more_space=(data_size*2);
  //if we dont have enough space
  if (reserved_size<data_size)
    reserve(more_space);

  //save old data
   for (int c=(data_size-1);c>i;c--)
     m_data[c]=m_data[(c-1)];
 
   //add x at pos i
   m_data[i]=x;

  return;
}

template <typename T>
void MyVector<T>::erase(int i)
{
  int afourth=reserved_size/4;
 
  if (data_size>0)
  {

    if (afourth>reserved_size)//array is less than 1/4 full
      shrink_to_fit();

    data_size--;

    for (int c=i; c<data_size; c++)
      m_data[c]=m_data[(c+1)];

  }

  return;
}

template <typename T>
int MyVector<T>::size()
{
  return data_size;//last is data_size-1 so +1 just data_size
}
