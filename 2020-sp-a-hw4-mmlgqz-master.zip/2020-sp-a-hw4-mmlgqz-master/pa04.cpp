/* Sample main
 * Disclaimer: this file is not a unit test!
 * Just because it runs, does NOT mean your assignment is correct.
 * This file is for developing your own tests.
 * We've included vector below to show you how your types should behave.
 * You can use that for debugging.
 * When implementing your list, you are expected to use the same names and declarations as defined by the STL implementation of an array list, the vector.
 * The vector you implement must be templated on the data type it stores.
*/

#include <vector>

#include "MyVector.h"

int main()
{
  // Uncomment this
  MyVector<int> v;
  //vector<int> v;

  cout << v.size() << endl;
  v.push_back(4000);
  cout << v.at(0) << endl;
  cout << v.capacity() << endl;
  v.reserve(10);
  cout << v.capacity() << endl;
  v.push_back(200);
  v.push_back(100);
  v.insert(v.begin(), 3);
  v.insert(v.end(), 20);

  // These are tricky. They look like iterators, but are really just integers.
  int j = 0;
  for(auto i = v.begin(); i < v.end(); i++)
  {
      cout << v.at(j) << endl;
      j++;
  }

  j = 0;
  for(auto i = 0; i < v.size(); i++)
  {
      cout << v[j] << endl;
      j++;
  }

  return 0;
}


