
template <typename E>
class Node 
{
  public: 
    E element;      
    Node *next;        

    Node(const E &elemval, Node *nextval=nullptr) 
    {
      element=elemval;
      next=nextval;
    }

    Node(Node *nextval=nullptr) 
    {
      next=nextval;
    }
};


