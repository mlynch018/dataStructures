#pragma once
// Do not edit this h file.
#include "MyGraph.h"


string import_problem();

