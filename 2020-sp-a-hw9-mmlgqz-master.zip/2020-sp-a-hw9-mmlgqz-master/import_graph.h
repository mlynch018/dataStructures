#pragma once
// Do not edit this h file.

#include "MyGraph.h"


MyGraph * import_graph();

