#ifndef DIJK_ELEM_H
#define DIJK_ELEM_H

class DijkElem 
{
  public:
    int vertex;
    float distance;

    DijkElem() 
    {
      vertex = -1;
      distance = -1;
    }

    DijkElem(int v, float d)
    {
        vertex = v;
        distance = d;
    }
};

#endif
