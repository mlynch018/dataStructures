/** 
 * Import one instance of a graph,
 * and save it's features in the graph object.
 * Define the import_graph function here.
 * It should create a dynamically allocated object and return it's address
 * You can change this file, as long as it returns what is needed,
 * and does not break the h file, and returns a pointer to your graph.
 * More details about running this in pa09.cpp
 **/

#include "MyGraph.h"
#include <string>
#include <iostream>
using namespace std;

//I think its done, look at comments___________________________________________*
MyGraph * import_graph()
{
  int n=0;
  MyGraph *g_temp;

  string line;
  std::getline(std::cin,line);

  for (int i = 0; i < line.size(); i++) 
  {
    if (line.substr(i,1) == ",") 
    {
      n++;
    }
  }

  g_temp = new MyGraph(n);
  int start;
  double dec;
  int vertexCount = 0;

  for (int i = 0; i < n; i++) 
  {
    std::getline(std::cin,line);
    start = 0;
    vertexCount = 0;

    for (int j = 0; j < line.size(); j++) 
    {
      if (line.substr(j,1) == "(") 
      {
        g_temp->set_node_name(i,line.substr(start,j-start-1));
        j++;
        start = j;
      } 
      else if (line.substr(j,1) == ")") 
      {
        dec = std::stod(line.substr(start,j - start));
        g_temp->set_bribe(i,dec);
        j++;
        start = j + 1;
      } 
      else if (line.substr(j,1) == ",") 
      {
        dec = std::stod(line.substr(start, j - start));
        if (dec) 
        {
          g_temp->set_edge(i,vertexCount,dec);
        }
        start = j + 1;
        vertexCount++;
      } 
      else if (j == line.size() - 1) 
      {
        dec = std::stod(line.substr(start, j - start + 1));
        if (dec) 
        {
          g_temp->set_edge(i,vertexCount,dec);
        }
      }
    }
  }

    return g_temp;
}

