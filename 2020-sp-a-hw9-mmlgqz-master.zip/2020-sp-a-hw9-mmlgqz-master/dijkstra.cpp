#include "dijkstra.h"
#include "DijkElem.h"
#include "DDComp.h"
#include "book.h"
#include "MyGraph.h"
#include "heap.h"
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
using namespace std;
using std::vector;


//couldnt get double to concatenate
string Cat(double arg)
{
  std::stringstream ss;
  //setprecision because the bribes with decimal.0 weren't showing
  ss << fixed<<showpoint<<setprecision(1)<<arg;
  return ss.str();
}


// Implement dikstra function in the corresponding h file.
void algorithm(MyGraph *G, double D[], int s, int end, int c, int P[], double &totalBribes)
{
  int i, v, w;            // v is current vertex
  P[s] = s;
  D[s] = 0; // set current nodes distance to 0

  DijkElem temp;
  temp.distance = 0;
  temp.vertex = s;

  DijkElem E[G->n_edges()];     // array with lots of space (for heap)
  E[0] = temp;            // Initialize heap array

  heap<DijkElem, DDComp> H(E, 1, G->n_edges()); // Create heap

  for (i = 0; i < G->n_nodes(); i++) 
  {
    do 
    {
      if (H.size() == 0) 
      {
        return; // Nothing to remove
      }
      temp = H.removefirst();
      v = temp.vertex;
    } while (G->getMark(v) == VISITED);

    G->setMark(v, VISITED);

    if (D[v] == INFINITY) 
    {
      return;    // Unreachable vertices
    }

    for (w = G->get_first_neighbor(v); w < G->n_nodes(); w = G->get_next_neighbor(v, w)) 
    {
      if(D[w] >= (D[v] + G->get_edge(v, w))) 
      {
        if (D[w] == (D[v] + G->get_edge(v, w))) 
        {
          float tempB = 0;
          int t = end;
          while (P[t] != s) 
          {
            t = P[t];
            tempB += G->get_bribe(t);
          }
          t = P[t];
          tempB += G->get_bribe(t);
          if (tempB < totalBribes) 
          {
            totalBribes = tempB;
            if(D[w] < INFINITY) 
            {
              P[w] = v;
            }
          }
        } 
        else 
        {
          D[w] = D[v] + G->get_edge(v, w);
          if(D[w] < INFINITY)
          {
            P[w] = v;
          }
          if (P[end] < INFINITY) 
          {
            totalBribes = 0;
            int temp1 = end;
            while (P[temp1] != s) 
            {
              temp1 = P[temp1];
              totalBribes += G->get_bribe(temp1);
            }
            temp1 = P[temp1];
            totalBribes += G->get_bribe(temp1);
          }
        }
        temp.distance = D[w];
        temp.vertex = w;
        H.insert(temp);
      }
    }
  }  


}

string dijkstra(MyGraph *G, std::string line)
{
  string ret="";
  string path="";
  string things="";
  string exchange="";

  //variable set up for algorithm
  int count=G->n_nodes();
  string home = "";
  string dest = "";
  int start = 31;

  for (int i = start; i < line.size(); i++) 
  {
    if (line.substr(i,1) == " ") 
    {
      home = line.substr(start, i - start - 1);
      i += 4;
      start = i;
    } 
    else if (line.substr(i,1) == "?") 
    {
      dest = line.substr(start, i - start - 1);
      break;
    }
  }

  double D[G->n_nodes()];

  for (int i = 0; i < G->n_nodes(); i++) 
  {
      D[i] = INFINITY;
  }

  int begin;
  int end;

  for (int i = 0; i < count; i++) 
  {
    if (G->get_node_name(i) == home) 
    {
      begin = i;
    } 
    else if (G->get_node_name(i) == dest) 
    {
      end = i;
    }
  }
  int P[count];
  for (int i = 0; i < count; i++) 
  {
    P[i] = INFINITY;
  }
  double totalBribes = 0;

//algorithm-----------------
algorithm(G,D,begin,end,count,P,totalBribes);
//output----------------------------
  double x=D[end];
  

  if (D[end] == INFINITY) 
  {
    path+= "There is no path from " + G->get_node_name(begin) + "s to "
        + G->get_node_name(end)+ "s.";
  } 
  else 
  {
    vector<string> output;
    int temp1 = end;
    while (P[temp1] != begin) 
    {
      output.push_back(G->get_node_name(temp1));
      temp1 = P[temp1];
    }
    output.push_back(G->get_node_name(temp1));
    temp1 = P[temp1];
    output.push_back(G->get_node_name(temp1));

    path+= "The shortest path from "+ G->get_node_name(begin)+ "s to "
        +G->get_node_name(end) + "s is:\n";

    while (output.size() != 0) 
    {
      string thing = output.back();
      output.pop_back();
      things+= thing + "s, ";
    }


    exchange+= "with sum exchange cost of ";
    exchange+=Cat(x);
    exchange+=" and bribe cost of ";
    exchange+=Cat(totalBribes);
   // exchange+="\n";
  }
  ret=path+things+exchange;  
  return ret;
}

