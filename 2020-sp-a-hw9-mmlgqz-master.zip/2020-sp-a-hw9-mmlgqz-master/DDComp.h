
#ifndef D_D_COMP_H
#define D_D_COMP_H

class DDComp 
{
  public:
    static bool prior(DijkElem x, DijkElem y) 
    {
        return x.distance < y.distance;
    }
};

#endif
