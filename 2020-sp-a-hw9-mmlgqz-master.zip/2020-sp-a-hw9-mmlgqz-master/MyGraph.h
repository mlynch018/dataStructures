#ifndef MYGRAPH_H
#define MYGRAPH_H

#include "graph.h"
#include "node.h"
//includes

#include <string>
#include <stdio.h>


#define UNVISITED 0
#define VISITED 1

// Define your MyGraph class 
// Inherit the abstract Graph class with public demotion.
// You can use whatever backend you like (hash tables, matrices, linked lists, etc.,).
// You can add as many functions as you like.
// You don't need a cpp/hpp file for this, and can just define everything in the h.

//WIP last 4 only_________________________________________________________*
class MyGraph: public Graph
{
    private:
      int numNodes;
      int numEdges;
      float **matrix;
      int *marker;  
      float *bribeVal;
      string *nameVal;
       
    public:
      //constructor added
      MyGraph(int numNodes)
      {
        createGraph(numNodes);             
      }
      //creates graph, helper for constructor added
      void createGraph(int x)
      {          
        numNodes=x;
        numEdges=0;
        marker=new int[x];
        bribeVal=new float[x];//int?
        nameVal=new string[x];//int?

        for (int i=0; i<numNodes; i++)
          marker[i]=UNVISITED;
       
        matrix=(float**) new float*[numNodes];
        
        for (int j=0; j<numNodes; j++)
          matrix[j]=new float[numNodes];


        for (int k=0; k<numNodes; k++)
        {
           for (int l=0; l<numNodes; l++)
             matrix[k][l]=0;
        }  
      }
      //destructor added
      ~MyGraph()
      {
         for (int i=0; i<numNodes; i++)
           delete [] matrix[i];
   
         delete [] matrix;
         delete [] marker;
      }

      int get_first_neighbor(int vert)
      {
        for (int i=0; i<numNodes; i++)
        {
           if(matrix[vert][i]!=0)
             return i;
        }
        return numNodes;
      }    

      int get_next_neighbor(int vert, int prev_neigh)
      {
        for (int i=(prev_neigh+1); i<numNodes; i++)
        {
          if (matrix[vert][i]!=0)
            return i;
        }
        return numNodes;
      }

      int n_nodes()
      {
        return numNodes;
      }

      int n_edges()
      {
        return numEdges;
      }

      void set_edge(int v1, int v2, float wght)
      {
//        int n=static_cast<int>(wght);
//        Assert(n>0, "Illegal Weight Value");        

        if(matrix[v1][v2]==0)
          numEdges++;

        matrix[v1][v2]=wght;        
      }
      
      void del_edge(int v1, int v2)
      {
        if(matrix[v1][v2]!=0)
          numEdges--;
        else 
          cout<<"Edge did not exist"<<endl;

         matrix[v1][v2]=0;
      }

      float get_edge(int v1, int v2)
      {
        return matrix[v1][v2];
      }

      //Do last four functions ________________________________________*
      //need to make a node for these with a name and bribe?
      void set_bribe(int v, float bribe)
      {
        bribeVal[v]=bribe;  
      }

      float get_bribe(int v)
      {
        return bribeVal[v];
        // return -1;//temp so will compile
      }

      void set_node_name(int v,string name)
      {
        nameVal[v]=name;
      }

      string get_node_name(int v)
      {
        return nameVal[v];
       // return "";//temp so will compile
      }

      //added
      int getMark(int v)
      {
        return marker[v];
      }

      void setMark(int v, int val)
      {
        marker[v]=val;
      }
};

#endif

