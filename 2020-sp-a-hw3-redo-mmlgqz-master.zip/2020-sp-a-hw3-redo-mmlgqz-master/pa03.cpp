/* Declare any non-required functions above main.
 * The duty of main here is to interact with the user, take in input, and manage wrapping output and runtime.
 * Remember, if you are considering putting something in main or a function, double check the specifications.
 * Each function should only do what it is specified to do, and no more.
 */

#include "maze.h"


int main()
{
 int col=0;
  int row=0;

  int rows;
  cin>>rows;

  string *p;

  int c=0;

  while (rows)
  {
    c++;

    cin.ignore(80,'\n');
    p=build_matrix(rows);
    fill_matrix(p,rows);

    find_start(p,rows,row,col);

    cout<<"Map "<<(c-1);

    if(find_exit(p,row,col))
    {
      cout<<" -- Solution found:"<<endl;
    }
    else
    {
      cout<<" -- No solution found:"<<endl;
    }

   
    print_matrix(p,rows);

    cin>>rows;

    delete_matrix(p);
  }


  return 0;

}

