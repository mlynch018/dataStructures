
/* Here in the .cpp you should define and implement everything declared in t
 */

#include "maze.h"


void get_identity(string &my_id)
{
  my_id="mmlgqz";
  return;
}


string * build_matrix(int rows)
{
  string * p=new string[rows];
  return p;
}


void fill_matrix(string *matrix, int rows)
{
  for (int i=0; i<rows; i++)
  {
     getline(cin,matrix[i]);
  }
  return;
}


void print_matrix(string *matrix, int rows)
{
  for (int i=0; i<rows; i++)
  {
     cout<<matrix[i]<<endl;
  }

  cout<<endl;

  return;
}

void delete_matrix(string *&matrix)
{
  delete[]matrix;
  matrix=nullptr;
  return;
}


void find_start(string *matrix, int rows, int &row, int &col)
{
  const char TARGET='N';
  int size=matrix[0].size();

  for (int i=0; i<rows; i++)
  {
    for (int j=0; j<size;j++)
    {
      if (matrix[i][j]==TARGET)
      {
        row=i;
        col=j;
      }
    }
  }
  return;
}

bool find_exit(string *matrix, int row, int col)
{
  const int NUM_DIR=4;
  string facing="";
  bool exited=false;

  //look for every direction
  for (int i=0; i<NUM_DIR; i++)
  {
    if (i==0)
      facing="WEST";
    if (i==1)
      facing="NORTH";
    if (i==2)
      facing="EAST";
    if (i==3)
      facing="SOUTH";

    //if you can move and have not reached end, then move
    if (valid_move(matrix,row,col,facing) && !exited)
    {
      //leave trail
      if(matrix[row][col]!='N')
        matrix[row][col]='@';

      //move
      if (facing=="WEST")
        col--;
      if (facing=="NORTH")
        row--;
      if (facing=="SOUTH")
        row++;
      if (facing=="EAST")
        col++;
 //recursion, if you find the exit or have reached the end, stop
      if(find_exit(matrix,row,col) || at_end(matrix,row,col))
        exited=true;
      else
      {
        //backtracking does the opposite of move
        if (facing=="WEST")
          col++;
        if (facing=="NORTH")
          row++;
        if (facing=="SOUTH")
          row--;
        if (facing=="EAST")
          col--;

        //don't leave a trail if you have to go backward
        if (matrix[row][col]!='N')
          matrix[row][col]=' ';
      }
    }
  }
  return exited;//solution found?
}

bool at_end(string *matrix, int row, int col)
{
  const char END='E';
  if (matrix[row][col]==END)
    return true;
  return false;
}

bool valid_move(string *matrix, int row, int col, string direction)
{
  if (direction=="WEST")
    col--;
  if (direction=="NORTH")
    row--;
  if (direction=="SOUTH")
    row++;
  if (direction=="EAST")
    col++;

  //if there is a wall, invalid move
  if (matrix[row][col]=='|')
    return false;

  //if you've already been there,dont go there
  if (matrix[row][col]=='@')
    return false;

  return true;
}
